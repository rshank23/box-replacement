"""FastAPI Integration API."""
