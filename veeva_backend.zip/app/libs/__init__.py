"""Shared libraries."""
